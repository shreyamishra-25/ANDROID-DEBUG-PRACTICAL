﻿using System;
using System.Windows.Forms;

namespace finallpwq2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLoadContacts_Click(object sender, EventArgs e)
        {
            // Your code to load contacts
        }

        private void btnSaveContacts_Click(object sender, EventArgs e)
        {
            // Your code to save contacts to DB
        }

        private void btnReportContacts_Click(object sender, EventArgs e)
        {
            // Your code to show contact report
        }

        private void btnLoadSMS_Click(object sender, EventArgs e)
        {
            // Your code to load SMS
        }

        private void btnSaveSMS_Click(object sender, EventArgs e)
        {
            // Your code to save SMS to DB
        }

        private void btnReportSMS_Click(object sender, EventArgs e)
        {
            // Your code to show SMS report
        }

        private void btnLoadCallLogs_Click(object sender, EventArgs e)
        {
            // Your code to load call logs
        }

        private void btnSaveCallLogs_Click(object sender, EventArgs e)
        {
            // Your code to save call logs to DB
        }

        private void btnReportCallLogs_Click(object sender, EventArgs e)
        {
            // Your code to show call logs report
        }

        private void btnLoadDeviceInfo_Click(object sender, EventArgs e)
        {
            // Your code to load device info
        }

        private void btnSaveDeviceInfo_Click(object sender, EventArgs e)
        {
            // Your code to save device info to DB
        }

        private void btnReportDeviceInfo_Click(object sender, EventArgs e)
        {
            // Your code to show device info report
        }
    }
}
