﻿namespace finallpwq2
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabContacts;
        private System.Windows.Forms.Button btnLoadContacts;
        private System.Windows.Forms.Button btnSaveContacts;
        private System.Windows.Forms.Button btnReportContacts;
        private System.Windows.Forms.DataGridView dataGridContacts;

        private System.Windows.Forms.TabPage tabSMS;
        private System.Windows.Forms.Button btnLoadSMS;
        private System.Windows.Forms.Button btnSaveSMS;
        private System.Windows.Forms.Button btnReportSMS;
        private System.Windows.Forms.DataGridView dataGridSMS;

        private System.Windows.Forms.TabPage tabCallLogs;
        private System.Windows.Forms.Button btnLoadCallLogs;
        private System.Windows.Forms.Button btnSaveCallLogs;
        private System.Windows.Forms.Button btnReportCallLogs;
        private System.Windows.Forms.DataGridView dataGridCallLogs;

        private System.Windows.Forms.TabPage tabDeviceInfo;
        private System.Windows.Forms.Button btnLoadDeviceInfo;
        private System.Windows.Forms.Button btnSaveDeviceInfo;
        private System.Windows.Forms.Button btnReportDeviceInfo;
        private System.Windows.Forms.RichTextBox richTextBoxDeviceInfo;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabContacts = new System.Windows.Forms.TabPage();
            this.btnLoadContacts = new System.Windows.Forms.Button();
            this.btnSaveContacts = new System.Windows.Forms.Button();
            this.btnReportContacts = new System.Windows.Forms.Button();
            this.dataGridContacts = new System.Windows.Forms.DataGridView();

            this.tabSMS = new System.Windows.Forms.TabPage();
            this.btnLoadSMS = new System.Windows.Forms.Button();
            this.btnSaveSMS = new System.Windows.Forms.Button();
            this.btnReportSMS = new System.Windows.Forms.Button();
            this.dataGridSMS = new System.Windows.Forms.DataGridView();

            this.tabCallLogs = new System.Windows.Forms.TabPage();
            this.btnLoadCallLogs = new System.Windows.Forms.Button();
            this.btnSaveCallLogs = new System.Windows.Forms.Button();
            this.btnReportCallLogs = new System.Windows.Forms.Button();
            this.dataGridCallLogs = new System.Windows.Forms.DataGridView();

            this.tabDeviceInfo = new System.Windows.Forms.TabPage();
            this.btnLoadDeviceInfo = new System.Windows.Forms.Button();
            this.btnSaveDeviceInfo = new System.Windows.Forms.Button();
            this.btnReportDeviceInfo = new System.Windows.Forms.Button();
            this.richTextBoxDeviceInfo = new System.Windows.Forms.RichTextBox();

            this.tabControl.SuspendLayout();
            this.tabContacts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridContacts)).BeginInit();
            this.tabSMS.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSMS)).BeginInit();
            this.tabCallLogs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridCallLogs)).BeginInit();
            this.tabDeviceInfo.SuspendLayout();
            this.SuspendLayout();

            // tabControl
            this.tabControl.Controls.Add(this.tabContacts);
            this.tabControl.Controls.Add(this.tabSMS);
            this.tabControl.Controls.Add(this.tabCallLogs);
            this.tabControl.Controls.Add(this.tabDeviceInfo);
            this.tabControl.Location = new System.Drawing.Point(12, 12);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(760, 437);
            this.tabControl.TabIndex = 0;

            // tabContacts
            this.tabContacts.Controls.Add(this.btnLoadContacts);
            this.tabContacts.Controls.Add(this.btnSaveContacts);
            this.tabContacts.Controls.Add(this.btnReportContacts);
            this.tabContacts.Controls.Add(this.dataGridContacts);
            this.tabContacts.Location = new System.Drawing.Point(4, 22);
            this.tabContacts.Name = "tabContacts";
            this.tabContacts.Padding = new System.Windows.Forms.Padding(3);
            this.tabContacts.Size = new System.Drawing.Size(752, 411);
            this.tabContacts.Text = "Contacts";
            this.tabContacts.UseVisualStyleBackColor = true;

            this.btnLoadContacts.Location = new System.Drawing.Point(6, 6);
            this.btnLoadContacts.Text = "Load Contacts";
            this.btnLoadContacts.Click += new System.EventHandler(this.btnLoadContacts_Click);

            this.btnSaveContacts.Location = new System.Drawing.Point(100, 6);
            this.btnSaveContacts.Text = "Save Contacts";
            this.btnSaveContacts.Click += new System.EventHandler(this.btnSaveContacts_Click);

            this.btnReportContacts.Location = new System.Drawing.Point(200, 6);
            this.btnReportContacts.Text = "View Report";
            this.btnReportContacts.Click += new System.EventHandler(this.btnReportContacts_Click);

            this.dataGridContacts.Location = new System.Drawing.Point(6, 35);
            this.dataGridContacts.Size = new System.Drawing.Size(740, 370);

            // tabSMS
            this.tabSMS.Controls.Add(this.btnLoadSMS);
            this.tabSMS.Controls.Add(this.btnSaveSMS);
            this.tabSMS.Controls.Add(this.btnReportSMS);
            this.tabSMS.Controls.Add(this.dataGridSMS);
            this.tabSMS.Location = new System.Drawing.Point(4, 22);
            this.tabSMS.Name = "tabSMS";
            this.tabSMS.Size = new System.Drawing.Size(752, 411);
            this.tabSMS.Text = "SMS";
            this.tabSMS.UseVisualStyleBackColor = true;

            this.btnLoadSMS.Location = new System.Drawing.Point(6, 6);
            this.btnLoadSMS.Text = "Load SMS";
            this.btnLoadSMS.Click += new System.EventHandler(this.btnLoadSMS_Click);

            this.btnSaveSMS.Location = new System.Drawing.Point(100, 6);
            this.btnSaveSMS.Text = "Save SMS";
            this.btnSaveSMS.Click += new System.EventHandler(this.btnSaveSMS_Click);

            this.btnReportSMS.Location = new System.Drawing.Point(200, 6);
            this.btnReportSMS.Text = "View Report";
            this.btnReportSMS.Click += new System.EventHandler(this.btnReportSMS_Click);

            this.dataGridSMS.Location = new System.Drawing.Point(6, 35);
            this.dataGridSMS.Size = new System.Drawing.Size(740, 370);

            // tabCallLogs
            this.tabCallLogs.Controls.Add(this.btnLoadCallLogs);
            this.tabCallLogs.Controls.Add(this.btnSaveCallLogs);
            this.tabCallLogs.Controls.Add(this.btnReportCallLogs);
            this.tabCallLogs.Controls.Add(this.dataGridCallLogs);
            this.tabCallLogs.Location = new System.Drawing.Point(4, 22);
            this.tabCallLogs.Name = "tabCallLogs";
            this.tabCallLogs.Size = new System.Drawing.Size(752, 411);
            this.tabCallLogs.Text = "Call Logs";
            this.tabCallLogs.UseVisualStyleBackColor = true;

            this.btnLoadCallLogs.Location = new System.Drawing.Point(6, 6);
            this.btnLoadCallLogs.Text = "Load Logs";
            this.btnLoadCallLogs.Click += new System.EventHandler(this.btnLoadCallLogs_Click);

            this.btnSaveCallLogs.Location = new System.Drawing.Point(100, 6);
            this.btnSaveCallLogs.Text = "Save Logs";
            this.btnSaveCallLogs.Click += new System.EventHandler(this.btnSaveCallLogs_Click);

            this.btnReportCallLogs.Location = new System.Drawing.Point(200, 6);
            this.btnReportCallLogs.Text = "View Report";
            this.btnReportCallLogs.Click += new System.EventHandler(this.btnReportCallLogs_Click);

            this.dataGridCallLogs.Location = new System.Drawing.Point(6, 35);
            this.dataGridCallLogs.Size = new System.Drawing.Size(740, 370);

            // tabDeviceInfo
            this.tabDeviceInfo.Controls.Add(this.btnLoadDeviceInfo);
            this.tabDeviceInfo.Controls.Add(this.btnSaveDeviceInfo);
            this.tabDeviceInfo.Controls.Add(this.btnReportDeviceInfo);
            this.tabDeviceInfo.Controls.Add(this.richTextBoxDeviceInfo);
            this.tabDeviceInfo.Location = new System.Drawing.Point(4, 22);
            this.tabDeviceInfo.Name = "tabDeviceInfo";
            this.tabDeviceInfo.Size = new System.Drawing.Size(752, 411);
            this.tabDeviceInfo.Text = "Device Info";
            this.tabDeviceInfo.UseVisualStyleBackColor = true;

            this.btnLoadDeviceInfo.Location = new System.Drawing.Point(6, 6);
            this.btnLoadDeviceInfo.Text = "Load Info";
            this.btnLoadDeviceInfo.Click += new System.EventHandler(this.btnLoadDeviceInfo_Click);

            this.btnSaveDeviceInfo.Location = new System.Drawing.Point(100, 6);
            this.btnSaveDeviceInfo.Text = "Save Info";
            this.btnSaveDeviceInfo.Click += new System.EventHandler(this.btnSaveDeviceInfo_Click);

            this.btnReportDeviceInfo.Location = new System.Drawing.Point(200, 6);
            this.btnReportDeviceInfo.Text = "View Report";
            this.btnReportDeviceInfo.Click += new System.EventHandler(this.btnReportDeviceInfo_Click);

            this.richTextBoxDeviceInfo.Location = new System.Drawing.Point(6, 35);
            this.richTextBoxDeviceInfo.Size = new System.Drawing.Size(740, 370);

            // Form1
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.tabControl);
            this.Name = "Form1";
            this.Text = "Android Data Extractor";

            this.tabControl.ResumeLayout(false);
            this.tabContacts.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridContacts)).EndInit();
            this.tabSMS.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSMS)).EndInit();
            this.tabCallLogs.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridCallLogs)).EndInit();
            this.tabDeviceInfo.ResumeLayout(false);
            this.ResumeLayout(false);
        }
    }
}
