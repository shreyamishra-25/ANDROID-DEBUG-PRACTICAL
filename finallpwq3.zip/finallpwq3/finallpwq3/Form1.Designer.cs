﻿using System.Windows.Forms;
using System;

namespace finallpwq2
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private Button btnInsertContact;
        private TextBox txtName;
        private TextBox txtPhoneNumber;
        private TextBox txtEmail;
        private DataGridView dataGridViewContacts;
        private Label lblName;
        private Label lblPhoneNumber;
        private Label lblEmail;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnInsertContact = new Button();
            this.txtName = new TextBox();
            this.txtPhoneNumber = new TextBox();
            this.txtEmail = new TextBox();
            this.dataGridViewContacts = new DataGridView();
            this.lblName = new Label();
            this.lblPhoneNumber = new Label();
            this.lblEmail = new Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewContacts)).BeginInit();
            this.SuspendLayout();

            this.btnInsertContact.Location = new System.Drawing.Point(12, 120);
            this.btnInsertContact.Name = "btnInsertContact";
            this.btnInsertContact.Size = new System.Drawing.Size(75, 23);
            this.btnInsertContact.TabIndex = 0;
            this.btnInsertContact.Text = "Insert Contact";
            this.btnInsertContact.UseVisualStyleBackColor = true;
            this.btnInsertContact.Click += new EventHandler(this.btnInsertContact_Click);

            this.txtName.Location = new System.Drawing.Point(100, 12);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(200, 20);
            this.txtName.TabIndex = 1;

            this.txtPhoneNumber.Location = new System.Drawing.Point(100, 40);
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.Size = new System.Drawing.Size(200, 20);
            this.txtPhoneNumber.TabIndex = 2;

            this.txtEmail.Location = new System.Drawing.Point(100, 70);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(200, 20);
            this.txtEmail.TabIndex = 3;

            this.dataGridViewContacts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewContacts.Location = new System.Drawing.Point(12, 150);
            this.dataGridViewContacts.Name = "dataGridViewContacts";
            this.dataGridViewContacts.Size = new System.Drawing.Size(500, 150);
            this.dataGridViewContacts.TabIndex = 4;

            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(12, 15);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(35, 13);
            this.lblName.TabIndex = 5;
            this.lblName.Text = "Name";

            this.lblPhoneNumber.AutoSize = true;
            this.lblPhoneNumber.Location = new System.Drawing.Point(12, 43);
            this.lblPhoneNumber.Name = "lblPhoneNumber";
            this.lblPhoneNumber.Size = new System.Drawing.Size(82, 13);
            this.lblPhoneNumber.TabIndex = 6;
            this.lblPhoneNumber.Text = "Phone Number";

            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(12, 73);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(35, 13);
            this.lblEmail.TabIndex = 7;
            this.lblEmail.Text = "Email";

            this.ClientSize = new System.Drawing.Size(540, 320);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblPhoneNumber);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.dataGridViewContacts);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtPhoneNumber);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.btnInsertContact);
            this.Name = "Form1";
            this.Text = "Android Data App";
            this.Load += new EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewContacts)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}


