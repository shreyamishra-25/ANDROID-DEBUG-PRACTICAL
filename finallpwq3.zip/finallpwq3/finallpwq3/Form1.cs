﻿using System;
using System.Windows.Forms;
using System.Xml.Linq;

namespace finallpwq2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInsertContact_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string phoneNumber = txtPhoneNumber.Text;
            string email = txtEmail.Text;

            DatabaseHelper dbHelper = new DatabaseHelper();
            dbHelper.InsertContact(name, phoneNumber, email);
            dbHelper.GetContacts(dataGridViewContacts);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DatabaseHelper dbHelper = new DatabaseHelper();
            dbHelper.GetContacts(dataGridViewContacts);
        }
    }
}
