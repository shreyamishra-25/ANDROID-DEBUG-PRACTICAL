﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

public class DatabaseHelper
{
    private string connectionString = "Server=(localdb)\\MSSQLLocalDB;Database=AndroidDataDB;Integrated Security=true";

    // Insert a contact into ContactsTable
    public void InsertContact(string name, string phoneNumber, string email)
    {
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();
            // Check if the contact already exists by phone number
            string checkQuery = "SELECT COUNT(*) FROM ContactsTable WHERE PhoneNumber = @PhoneNumber";

            using (SqlCommand cmd = new SqlCommand(checkQuery, conn))
            {
                cmd.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                int count = (int)cmd.ExecuteScalar();

                if (count == 0)
                {
                    string query = "INSERT INTO ContactsTable (Name, PhoneNumber, Email) VALUES (@Name, @PhoneNumber, @Email)";
                    using (SqlCommand insertCmd = new SqlCommand(query, conn))
                    {
                        insertCmd.Parameters.AddWithValue("@Name", name);
                        insertCmd.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                        insertCmd.Parameters.AddWithValue("@Email", email);
                        insertCmd.ExecuteNonQuery();
                    }
                }
                else
                {
                    MessageBox.Show("This contact already exists!");
                }
            }
        }
    }

    // Get all contacts and display in DataGridView
    public void GetContacts(DataGridView dataGridView)
    {
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();
            string query = "SELECT * FROM ContactsTable";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                SqlDataReader reader = cmd.ExecuteReader();
                var table = new DataTable();
                table.Load(reader);
                dataGridView.DataSource = table;
            }
        }
    }

    // Insert a message into MessagesTable
    public void InsertMessage(string sender, string messageContent, DateTime timestamp)
    {
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();
            string query = "INSERT INTO MessagesTable (Sender, MessageContent, Timestamp) VALUES (@Sender, @MessageContent, @Timestamp)";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Sender", sender);
                cmd.Parameters.AddWithValue("@MessageContent", messageContent);
                cmd.Parameters.AddWithValue("@Timestamp", timestamp);
                cmd.ExecuteNonQuery();
            }
        }
    }

    // Get all messages and display in DataGridView
    public void GetMessages(DataGridView dataGridView)
    {
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();
            string query = "SELECT * FROM MessagesTable";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                SqlDataReader reader = cmd.ExecuteReader();
                var table = new DataTable();
                table.Load(reader);
                dataGridView.DataSource = table;
            }
        }
    }

    // Insert a call log into CallLogsTable
    public void InsertCallLog(string phoneNumber, string callType, int duration)
    {
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();
            string query = "INSERT INTO CallLogsTable (PhoneNumber, CallType, Duration) VALUES (@PhoneNumber, @CallType, @Duration)";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                cmd.Parameters.AddWithValue("@CallType", callType);
                cmd.Parameters.AddWithValue("@Duration", duration);
                cmd.ExecuteNonQuery();
            }
        }
    }

    // Get all call logs and display in DataGridView
    public void GetCallLogs(DataGridView dataGridView)
    {
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();
            string query = "SELECT * FROM CallLogsTable";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                SqlDataReader reader = cmd.ExecuteReader();
                var table = new DataTable();
                table.Load(reader);
                dataGridView.DataSource = table;
            }
        }
    }

    // Insert device info into DeviceInfoTable
    public void InsertDeviceInfo(string cpuInfo, string memoryInfo)
    {
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();
            string query = "INSERT INTO DeviceInfoTable (CPUInfo, MemoryInfo) VALUES (@CPUInfo, @MemoryInfo)";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@CPUInfo", cpuInfo);
                cmd.Parameters.AddWithValue("@MemoryInfo", memoryInfo);
                cmd.ExecuteNonQuery();
            }
        }
    }

    // Get all device info and display in DataGridView
    public void GetDeviceInfo(DataGridView dataGridView)
    {
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();
            string query = "SELECT * FROM DeviceInfoTable";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                SqlDataReader reader = cmd.ExecuteReader();
                var table = new DataTable();
                table.Load(reader);
                dataGridView.DataSource = table;
            }
        }
    }
}
