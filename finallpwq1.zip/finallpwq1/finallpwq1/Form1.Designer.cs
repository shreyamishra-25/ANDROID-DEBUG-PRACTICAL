﻿namespace finallpwq1
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnGetContacts;
        private System.Windows.Forms.Button btnGetSMS;
        private System.Windows.Forms.Button btnGetCallLogs;
        private System.Windows.Forms.RichTextBox richTextBoxData;
        private System.Windows.Forms.ListBox listBoxContacts;
        private System.Windows.Forms.ListBox listBoxSMS;
        private System.Windows.Forms.ListBox listBoxCallLogs;


        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnGetContacts = new System.Windows.Forms.Button();
            this.btnGetSMS = new System.Windows.Forms.Button();
            this.btnGetCallLogs = new System.Windows.Forms.Button();
            this.richTextBoxData = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();

            // 
            // btnGetContacts
            // 
            this.btnGetContacts.Location = new System.Drawing.Point(12, 12);
            this.btnGetContacts.Name = "btnGetContacts";
            this.btnGetContacts.Size = new System.Drawing.Size(75, 23);
            this.btnGetContacts.TabIndex = 0;
            this.btnGetContacts.Text = "Get Contacts";
            this.btnGetContacts.UseVisualStyleBackColor = true;
            this.btnGetContacts.Click += new System.EventHandler(this.btnGetContacts_Click);

            // 
            // btnGetSMS
            // 
            this.btnGetSMS.Location = new System.Drawing.Point(12, 41);
            this.btnGetSMS.Name = "btnGetSMS";
            this.btnGetSMS.Size = new System.Drawing.Size(75, 23);
            this.btnGetSMS.TabIndex = 1;
            this.btnGetSMS.Text = "Get SMS";
            this.btnGetSMS.UseVisualStyleBackColor = true;
            this.btnGetSMS.Click += new System.EventHandler(this.btnGetSMS_Click);

            // 
            // btnGetCallLogs
            // 
            this.btnGetCallLogs.Location = new System.Drawing.Point(12, 70);
            this.btnGetCallLogs.Name = "btnGetCallLogs";
            this.btnGetCallLogs.Size = new System.Drawing.Size(75, 23);
            this.btnGetCallLogs.TabIndex = 2;
            this.btnGetCallLogs.Text = "Get Call Logs";
            this.btnGetCallLogs.UseVisualStyleBackColor = true;
            this.btnGetCallLogs.Click += new System.EventHandler(this.btnGetCallLogs_Click);

            // 
            // richTextBoxData
            // 
            this.richTextBoxData.Location = new System.Drawing.Point(100, 12);
            this.richTextBoxData.Name = "richTextBoxData";
            this.richTextBoxData.Size = new System.Drawing.Size(350, 250);
            this.richTextBoxData.TabIndex = 3;
            this.richTextBoxData.Text = "";

            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(462, 273);
            this.Controls.Add(this.richTextBoxData);
            this.Controls.Add(this.btnGetCallLogs);
            this.Controls.Add(this.btnGetSMS);
            this.Controls.Add(this.btnGetContacts);
            this.Name = "Form1";
            this.Text = "Android Data Extractor";
            this.ResumeLayout(false);
        }
    }
}
