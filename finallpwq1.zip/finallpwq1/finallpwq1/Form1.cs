﻿using System;
using System.IO;
using System.Windows.Forms;

namespace finallpwq1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Method to read Contacts data from file and display it
        private void btnLoadContacts_Click(object sender, EventArgs e)
        {
            string filePath = @"C:\Users\SHREYA MISHRA\Downloads\platform-tools\contacts.txt";  // Change this to your file path

            if (File.Exists(filePath))
            {
                string[] data = File.ReadAllLines(filePath);
                listBoxContacts.Items.Clear();
                foreach (string line in data)
                {
                    listBoxContacts.Items.Add(line);  // Add each contact to the ListBox
                }
            }
            else
            {
                MessageBox.Show("Contacts file not found.");
            }
        }

        // Method to read SMS data from file and display it
        private void btnLoadSMS_Click(object sender, EventArgs e)
        {
            string filePath = @"C:\Users\SHREYA MISHRA\Downloads\platform-tools\sms.txt";  // Change this to your file path

            if (File.Exists(filePath))
            {
                string[] data = File.ReadAllLines(filePath);
                listBoxSMS.Items.Clear();
                foreach (string line in data)
                {
                    listBoxSMS.Items.Add(line);  // Add each SMS message to the ListBox
                }
            }
            else
            {
                MessageBox.Show("SMS file not found.");
            }
        }

        // Method to read Call Logs data from file and display it
        private void btnLoadCallLogs_Click(object sender, EventArgs e)
        {
            string filePath = @"C:\path\to\your\call_logs.txt";  // Change this to your file path

            if (File.Exists(filePath))
            {
                string[] data = File.ReadAllLines(filePath);
                listBoxCallLogs.Items.Clear();
                foreach (string line in data)
                {
                    listBoxCallLogs.Items.Add(line);  // Add each call log to the ListBox
                }
            }
            else
            {
                MessageBox.Show("Call Logs file not found.");
            }
        }
        private void btnGetContacts_Click(object sender, EventArgs e)
        {
            // Example: Load contacts from a file and display in listBoxContacts
            string filePath = @"C:\Path\To\contacts.txt"; // Change this to your actual path
            if (File.Exists(filePath))
            {
                string[] lines = File.ReadAllLines(filePath);
                listBoxContacts.Items.Clear();
                foreach (string line in lines)
                {
                    listBoxContacts.Items.Add(line);
                }
            }
            else
            {
                MessageBox.Show("Contacts file not found.");
            }
        }

        private void btnGetSMS_Click(object sender, EventArgs e)
        {
            string filePath = @"C:\Path\To\sms.txt"; // Change to the actual path of your SMS file
            if (File.Exists(filePath))
            {
                string[] lines = File.ReadAllLines(filePath);
                listBoxSMS.Items.Clear();
                foreach (string line in lines)
                {
                    listBoxSMS.Items.Add(line);
                }
            }
            else
            {
                MessageBox.Show("SMS file not found.");
            }
        }

        private void btnGetCallLogs_Click(object sender, EventArgs e)
        {
            string path = "calllogs.txt";
            if (File.Exists(path))
            {
                listBoxCallLogs.Items.Clear();
                foreach (string line in File.ReadAllLines(path))
                {
                    listBoxCallLogs.Items.Add(line);
                }
            }
            else
            {
                MessageBox.Show("calllogs.txt not found.");
            }

        }
    }
}
